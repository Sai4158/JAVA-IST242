package view;/*
 * Filename: View.java
 * Short description: Handles the display of information to the user.
 * IST 242 Assignment: L01C
 * @author  Sai Rangineeni
 * @version 2/10/2024
 */


public class View {
    // Method for displaying a string in the console
        public void basicDisplay(String s){
            System.out.println(s);
    }

}
