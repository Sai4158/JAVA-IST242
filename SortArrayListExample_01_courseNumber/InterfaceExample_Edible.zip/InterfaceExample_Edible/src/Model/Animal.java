/***************************************
* Filename: Animal.java
* Short description: This class ...
* @author Nannette D'Imperio
* @version  1/28/2019
***************************************/

package Model;

/**
 *
 * @author nxd13
 */
public abstract class Animal {
    /** Return animal sound */
    public abstract String sound();
}
