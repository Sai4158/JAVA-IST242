/***************************************
* Filename: Orange.java
* Short description: This class ...
* @author Nannette D'Imperio
* @version  1/28/2019
***************************************/

package Model;

/**
 *
 * @author nxd13
 */
public class Orange extends Fruit {

    @Override
    public String howToEat() {
        return "Orange: Make orange juice";
    }

}
