/***************************************
* Filename: Chicken.java
* Short description: This class ...
* @author Nannette D'Imperio
* @version  1/28/2019
***************************************/

package Model;

/**
 *
 * @author nxd13
 */
public class Chicken extends Animal implements Edible {

    @Override
    public String sound() {
        return "Chicken: cock-a-doodle-doo";
    }

    @Override
    public String howToEat() {
        return "Chicken: Fry it";
    }

}
