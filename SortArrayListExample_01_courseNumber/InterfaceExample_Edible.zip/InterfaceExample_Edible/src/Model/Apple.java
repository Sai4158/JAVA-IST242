/***************************************
* Filename: Apple.java
* Short description: This class ...
* @author Nannette D'Imperio
* @version  1/28/2019
***************************************/

package Model;

/**
 *
 * @author nxd13
 */
public class Apple extends Fruit {

    @Override
    public String howToEat() {
        return "Apple: Make apple cider";
    }

}
