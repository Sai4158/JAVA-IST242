/***************************************
* Filename: Edible.java
* Short description: This interface will be used to implement behavior ...
* @author Nannette D'Imperio
* @version  1/28/2019
***************************************/
package Model;

/**
 *
 * @author nxd13
 */
public interface Edible {
    /** Describe how to eat */
    public abstract String howToEat();
}
