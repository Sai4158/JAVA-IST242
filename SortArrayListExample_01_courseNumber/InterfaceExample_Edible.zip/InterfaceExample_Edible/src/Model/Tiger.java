/***************************************
* Filename: Tiger.java
* Short description: This class ...
* @author Nannette D'Imperio
* @version  1/28/2019
***************************************/

package Model;

/**
 *
 * @author nxd13
 */
public class Tiger extends Animal {

    @Override
    public String sound() {
        return "Tiger: RROOAARR";
    }
    
}
