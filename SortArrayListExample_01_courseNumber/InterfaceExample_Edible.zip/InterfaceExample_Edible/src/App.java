/***************************************
* Filename: App.java
* Short description: This program demonstrates the use of abstract classes and interfaces.
* @author Nannette D'Imperio
* @version  1/28/2019
***************************************/
import Model.*;

/**
 *
 * @author nxd13
 */
public class App {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Create objects
        Object[] objects =
            { new Tiger(), new Chicken(), new Apple(), new Orange() };
    
        // Display information about the objects
        for (int i = 0; i < objects.length; i++) {
            // Edible objects
            if (objects[i] instanceof Edible)
                System.out.println( ((Edible)objects[i]).howToEat() );
            // Animal objects
            if (objects[i] instanceof Animal)
                System.out.println( ((Animal)objects[i]).sound() );
        }
    }

}
