package View;

import javax.swing.*;

public class InitialPannel extends JPanel {
    private Array
}
