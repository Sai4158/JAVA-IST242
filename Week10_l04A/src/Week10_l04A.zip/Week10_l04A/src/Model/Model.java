package Model;/*
 * Filename: Model.java
 * Short description:
 * IST 242 Assignment:
 * @author  YOUR NAME HERE
 * @version 2/27/2024
 */


/**
 * @author saira
 * @version 1.0 2/27/2024
 */
public class Model {
    // Instance Variables -- define your private data


    // Constructors
    public Model() {
        // initialize default values
    }

    public Model(int data) // pass in data to initialize variables
    {
    }

    // Set methods - one set method for each instance variable defined above
    //             - purpose is to pass in a value stored in the private variable

    // Get methods - one get method for each instance variable defined above
    //             - purpose is to return the value stored in the private variable

    // Additional methods -- such as for calculation, display

    public String toString() {
        // return data as a String
        return "";
    }

}
