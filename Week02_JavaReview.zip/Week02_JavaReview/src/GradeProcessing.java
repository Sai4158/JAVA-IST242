/** Programmer; Sai Rangineeni
//File name ; GradeProcessing
// Date ; 1/16/2024
// verision - 1.0 (still working)
*/
import java.io.File
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
public class GradeProcessing {
    public static void main(String[] args){

        //Program descprtion
        programDescription();

        //Decalre varibles
        int choice;

        //input arrays
        ArrayList<String> data = null;
        String[] data = null;
        String[] names = null;
        double[][] exams;

        //define other methods
        double[] averages;
        String[] grades;

        //procees data
      do {  choice = printMenu();
        System.out.println("main: " + choice);

        // switch statment
          switch (choice){
            case 1: // read file
                data = readFile();

                break;
            case 2: //extract
                if (data != null) {
                    names = new String[data.size()];
                    exams = new double[data.size()][];
                    extractData(data, names, exams);
                }
                break;

            case 3: // displayinput
                displayInputData(names, exam);

                break;
            case 4: //calcAverages
                averages = calcAverages(exams);
                break;
            case 5 // getLettergrades
                break;
              case 6:
                  displayResults(names,)
                  break;
            case 6: //writeResults
                if (grades !=null){
                    writeResults(names, averages, grades);
                } else {
                    System.out.println("Must process all data in options 1 - 6 first");
                }
                break;
            case 0: // quit
                System.out.println("Goodbye!"); break;

      while(choice != 0);
    }

    public static void programDescription() {
        System.out.println("This progra will read student input from a file and offer a menu.");
    }
    public static int printMenu() {
        int choice;
        Scanner scan =new Scanner(System.in);
    //display menu
        System.out.println("\n Choose one of the following options: ");
        System.out.println("Press 1 to read contents from file");
        System.out.println("Press 2 to extract student names and grades");
        System.out.println("Press 3 to print student names and grades in table format");
        System.out.println("Press 4 to calculate student averages");
        System.out.println("Press 5 to calculate the letter grades");
        System.out.println("Press 6 to display the student names, averages and letter grades");
        System.out.println("Press 7 to write the data results to a file");
        System.out.println("Press 0 to exit");
        System.out.println("Enter choice:");
        choice = scan.nextInt();
        return 0;
    }
    while(choice < 0 || choice >7 );
        return choice;

    public static ArrayList<String> readFile() { //choice 1
        Scanner scan = new Scanner(System.in);
        ArrayList<String> data = new ArrayList<String>();
        String filename;
        System.out.print("Enter name of input file: ");
        filename = scan.next(); //studInfo.txt
      try {
            File file = new File(filename);
            Scanner filein = new Scanner(file);
            // loop tp read data and populate the arrayList
            while (fileIn.hasNext()) {
           data.add(filein.nextLine());
            }
          filein.close();

        } catch (FileNoteFoundException ex) {
          System.out.println("Input file not found. try again.");
          return data;

      }

        }

        return null;
    }
    public static void extractData(ArraysList[] data, String[] names, double[][] exams){ //choice 2
    // create the array - using size of data
            names = new String[data.size()];
            exams = new double[data.size()][4];
            //process on element from the arraylist and split into the 2 arrays
            for (int i = 0; i < data.size(); i++) {
                dataIn = new Scanner(data.get(i));
                //extract the name and place in names array
                names[i] = data.In.next():
                //loop to read in the exam grades - load exams
                for (int j = 0; j < exams[i].length;)
                    exams[i][j] = dataIn.nextDouble();
            }
    }
      System.out.println(names);
      System.out.println();
    public static void displayInputData(String[] names, double[][] exams){ //choice 3

    }
    public static double [] calcAverages(double[][] exams){ //choice 4
       double[] avgs = new double[exams.lenght];


        return null;
    }

    public static String[] getLetterGrade(double[] avg){ //choice 5
        return null;
    }
    public static void displayResults(String[] names, double[] avg, String[] grades) {//choice 6

    }

        public static void writeResults(String[] names, double[] averages, String[] grades) {
            // Implementation to write results to a file
    }
}
