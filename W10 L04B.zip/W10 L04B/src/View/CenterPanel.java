package View;
/**
 * Filename: CenterPanel.java
 * Short description: The panel that displays the data
 * IST 242 Assignment: L04B
 * @author Sai Rangineeni
 * @version 3/28/2024
 */

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class CenterPanel extends JPanel {
    //ArrayList
    private ArrayList<JLabel> headerLabels;
    // Represents rows of data
    private ArrayList<ArrayList<JButton>> dataButtons;

    public CenterPanel(ArrayList<String> headers, ArrayList<ArrayList<String>> dataRows) {
        setLayout(new BorderLayout());

        // A panel with a gray background
        JPanel headerPanel = new JPanel(new GridLayout(1, headers.size()));

        // Light gray background
        //Red, green, blue
        headerPanel.setBackground(new Color(211, 211, 211));
        headerLabels = new ArrayList<>();
        for (String header : headers) {
            JLabel label = new JLabel(header, SwingConstants.CENTER);
            headerPanel.add(label);
            headerLabels.add(label);
        }
        add(headerPanel, BorderLayout.NORTH);

        // Create a panel for the data rows
        JPanel dataPanel = new JPanel(new GridLayout(dataRows.size(), headers.size()));
        dataButtons = new ArrayList<>();
        for (ArrayList<String> row : dataRows) {
            ArrayList<JButton> buttonRow = new ArrayList<>();
            for (String cell : row) {
                JButton button = new JButton(cell);
                dataPanel.add(button);
                buttonRow.add(button);
            }
            dataButtons.add(buttonRow);
        }
        add(new JScrollPane(dataPanel), BorderLayout.CENTER);
    }
}
