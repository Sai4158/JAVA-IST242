package View;

public class View
{
//

    public View()
    {
//
    }

    public void display(String s)  //View likes Strings  //View doesn't know about data/model
    {
        System.out.println(s);
    }
}
