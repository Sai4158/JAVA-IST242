package Model;
/**
 * Filename: TableData.java
 * Short description: Interface
 * IST 242 Assignment: L05
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/21/2024
 */

import java.util.ArrayList;

public interface TableData {
    void loadTable();
    ArrayList<TableMember> getTable();
    ArrayList<String> getHeaders();
    ArrayList<String> getLine(int line);
    ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine);
}
