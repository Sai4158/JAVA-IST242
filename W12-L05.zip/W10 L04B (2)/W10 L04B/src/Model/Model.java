package Model;
/**
 * Filename: Model.java
 * Short description: Represents the application's data
 * IST 242 Assignment: L05
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/21/2024
 */
import java.util.ArrayList;

public class Model {
    private FootballPlayerData fpData;
    private ArrayList<ArrayList<String>> lines;

    // Constructor for FootballPlayerData and sets
    public Model() {
        fpData = new FootballPlayerData();
        fpData.setFirstLineToDisplay(0);
        fpData.setLastLineToDisplay(19);
        fpData.setLinesBeingDisplayed(20);
        // Fetch initial data
        lines = fpData.getLines(fpData.getFirstLineToDisplay(), fpData.getLastLineToDisplay());

    }

    //Get
    public FootballPlayerData getFpData() {
        return fpData;
    }

    // Set
    public void setFpData(FootballPlayerData fpd) {
        this.fpData = fpd;
    }

    // Returns the current list
    public ArrayList<ArrayList<String>> getLines() {
        // Update and return lines
        lines = fpData.getLines(fpData.getFirstLineToDisplay(), fpData.getLastLineToDisplay());
        return lines;

    }



}