package Model;
/**
 * Filename: FootballPlayerData.java
 * Short description: list of football players with there data
 * IST 242 Assignment: L05
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/21/2024
 */
import java.util.Arrays;
import java.util.Comparator;
import java.beans.XMLDecoder;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.Collections;
import java.util.ArrayList;


public class FootballPlayerData implements TableData, Displayable, Sortable {

    private ArrayList<FootballPlayer> players;

    // Instance variables
    private int lastLineToDisplay;
    private int linesBeingDisplayed;
    private int sortField;
    private int firstLineToDisplay;
    private int lineToHighlight;
    private int sortType;
    private Comparator<FootballPlayer> field;

    public FootballPlayerData() {
        players = new ArrayList<>();
        loadTable();
    }

    @Override
    public void loadTable() {
        //loads our table of data
        ReadPlayersFromXML();
    }

    @Override
    public ArrayList getTable() {
        return players;
    }
    @Override
    public ArrayList<String> getHeaders() {
        ArrayList<String> headers = players.get(0).getAttributeNames();
        return headers;
    }
    @Override
    public ArrayList<String> getLine(int line) {
        ArrayList<String> data = players.get(line).getAttributes();
        return data;
    }
    @Override
    public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine) {
        ArrayList<ArrayList<String>> lines = new ArrayList<>();
        for (int i = firstLine; i < lastLine && i < players.size(); i++) {
            lines.add(getLine(i));
        }
        return lines;
    }

    public void ReadPlayersFromXML() {
        try {
            FootballPlayer fp;
            XMLDecoder decoder;
            decoder = new XMLDecoder(new BufferedInputStream(new FileInputStream("W10 L04B/src/FootballPlayerTable.xml")));
            fp = new FootballPlayer();
            while (fp != null) {
                try {
                    fp = (FootballPlayer) decoder.readObject();
                    players.add(fp);

                }
                catch (ArrayIndexOutOfBoundsException theend) {

                    break;
                }
            }
            decoder.close();
        }
        catch (Exception xx) {
            xx.printStackTrace();
        }
    }

    @Override
    public int getFirstLineToDisplay() {
        return firstLineToDisplay;
    }
    @Override
    public int getLineToHighlight() {
        return lineToHighlight;
    }
    @Override
    public int getLastLineToDisplay() {
        return lastLineToDisplay;
    }
    @Override
    public int getLinesBeingDisplayed() {
        return linesBeingDisplayed;
    }
    @Override
    public void setFirstLineToDisplay(int firstLine) {
        firstLineToDisplay = firstLine;
    }
    @Override
    public void setLineToHighlight(int highlightedLine) {
        lineToHighlight = highlightedLine;
    }
    @Override
    public void setLastLineToDisplay(int lastLine) {
        lastLineToDisplay = lastLine;
    }
    @Override
    public void setLinesBeingDisplayed(int numberOfLines) {
        linesBeingDisplayed = numberOfLines;
    }
    @Override
    public void sort(int sortType, int sortField) {
        setSortField(sortField);
        setSortType(sortType);
        System.out.println("Sort type: " + sortType + " " + sortField);

        switch(sortType)
        {
            // Selection Sort
            case 1:
                selectionSort();
                break;
            // Merge Sort
            case 2:
                Collections.sort(players,field);
                break;
            // Quick Sort
            case 3:
                //ArrayList to array
                FootballPlayer[] array = copyList(players);
                Arrays.sort(array, field);
                players = new ArrayList<FootballPlayer>(Arrays.asList(array));
        }
    }
    private FootballPlayer[] copyList(ArrayList<FootballPlayer> players) {
        FootballPlayer[] arr = new FootballPlayer[players.size()];
        for (int i = 0; i < players.size(); i++) {
            arr[i] = players.get(i);
        }
        return arr;
    }
    private void selectionSort() {
        for (int i = 0; i < players.size(); i++) {
            //lowest value
            int minPos = minimumPosition(players,i);

            // Swap if necessary.
            if (minPos != i) {
                swap(players, minPos, i);
            }

        }
    }

    private void swap(ArrayList<FootballPlayer> courses, int a, int b) {
        // Save the value in position.
        FootballPlayer temp = players.get(a);
        players.set(a, players.get(b));
        players.set(b, temp);
    }

    private int minimumPosition(ArrayList<FootballPlayer> footballPlayers, int from) {
        int minPos = from;
        for (int a = from; a < players.size(); a++) {
            if (players.get(a).getAttribute(sortField).compareTo(
                    players.get(minPos).getAttribute(sortField)) < 0) {
                minPos  = a;
            }
        }
        return minPos;
    }
    @Override
    public int getSortType() {
        return sortType;
    }

    @Override
    public void SetSortType(int sortType) {

    }

    public void setSortType(int sortType) {
        this.sortType = sortType;
    }
    @Override
    public int getSortField() {
        return sortField;
    }

    @Override
    public void SetSortField(int sortField) {
    }

    public void setSortField(int sortField)
    {
        this.sortField = sortField;

        // variable
        switch (sortField) {
            case 0: field = sortByNumber ; break;
            case 1: field = sortByName; break;
            case 2: field = sortByPosition; break;
            case 3: field = sortByHeight; break;
            case 4: field = sortByWeight; break;
            case 5: field = sortByHomeTown; break;
            case 6: field = sortByHighSchool; break;
        }

    }

    //Merge and Quick Sorts
    Comparator<FootballPlayer> sortByName = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer o1, FootballPlayer o2) {
            // FootballPlayer Name
            return o1.getName().compareTo(o2.getName());
        }
    };
    Comparator<FootballPlayer> sortByPosition = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer o1, FootballPlayer o2) {
            return o1.getPosition().compareTo(o2.getPosition());
        }
    };
    Comparator<FootballPlayer> sortByNumber = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer o1, FootballPlayer o2) {
            if (o1.getNumber() < o2.getNumber()) {
                return -1;
            }
            if (o1.getNumber() == o2.getNumber()) {
                return 0;
            }
            return 1;
        }
    };
    Comparator<FootballPlayer> sortByHeight = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer o1, FootballPlayer o2) {
            if ((o1.getHeight().getFeet() * 12) + o1.getHeight().getInches() <
                    (o2.getHeight().getFeet() * 12) + o2.getHeight().getInches()) {
                return -1;
            }
            if ((o1.getHeight().getFeet() * 12) + o1.getHeight().getInches() ==
                    (o2.getHeight().getFeet() * 12) + o2.getHeight().getInches()) {
                return 0;
            }
            return 1;
        }
    };
    Comparator<FootballPlayer> sortByWeight = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer o1, FootballPlayer o2) {
            if (o1.getWeight() < o2.getWeight()) {
                return -1;
            }
            if (o1.getWeight() == o2.getWeight()) {
                return 0;
            }
            return 1;
        }
    };
    Comparator<FootballPlayer> sortByHomeTown = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer o1, FootballPlayer o2) {
            return o1.getHometown().compareTo(o2.getHometown());
        }
    };
    Comparator<FootballPlayer> sortByHighSchool = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer o1, FootballPlayer o2) {
            return o1.getHighSchool().compareTo(o2.getHighSchool());
        }
    };
}
