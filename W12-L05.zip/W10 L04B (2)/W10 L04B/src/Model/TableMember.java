package Model;
/**
 * Filename: TableMember.java
 * Short description: Interface
 * IST 242 Assignment: L05
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/21/2024
 */
import java.util.ArrayList;

public interface TableMember {
    String getAttribute(int n);
    String getAttributeName(int n);
    ArrayList<String> getAttributes();
    ArrayList<String> getAttributeNames();
}
