package Model;
/**
 * Filename: Sortable.java
 * Short description: interfacee
 * IST 242 Assignment: L05
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/21/2024
 */
public interface Sortable {
    public void sort(int sortType, int sortField);
    public int getSortType();
    public void SetSortType(int sortType);
    public int getSortField();
    public void SetSortField(int sortField);
}
