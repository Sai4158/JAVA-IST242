package Model;
/**
 * Filename: FootballPlayer.java
 * Short description: Represents a football player
 * IST 242 Assignment: L05
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/21/2024
 */
import java.util.ArrayList;


public class FootballPlayer extends Person implements TableMember {
    // Instance variables
    private int number;
    private String position;

    //Default constructor
    public FootballPlayer() {
        super("", new Height(0,0), 0, "N/A", "N/A");
        this.number = 0;
        this.position = "N/A";
    }

    // Constructor
    public FootballPlayer(String Name, Height Height, int Weight, String HT, String HS, int Numb, String player) {
        super(Name, Height, Weight, HT, HS);
        this.number = Numb;
        this.position = player;
    }

    // Setter
    public void setNumber(int number) {
        this.number = number;
    }

    // Setter f
    public void setPosition(String position) {
        this.position = position;
    }

    // Getter
    public int getNumber() {
        return this.number;
    }

    // Getter
    public String getPosition() {
        return this.position;
    }

  // Retrieves attribute based on index for tabular display.
    @Override
    public String getAttribute(int n) {
        switch(n) {
            case 0:
                return String.valueOf(number);
            case 1:
                return position;
            case 2:
                return super.getName();
            case 3:
                return super.getHeight().toString();
            case 4:
                return String.valueOf(super.getWeight());
            case 5:
                return super.getHometown();
            case 6:
                return super.getHighSchool();
            default:
                return "";
        }
    }

   // Collects all attributes in a list for tabular display.
    @Override
    public ArrayList<String> getAttributes() {
        ArrayList<String> attributes = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            attributes.add(getAttribute(i));
        }
        return attributes;
    }

    // Retrieves attribute name
    @Override
    public String getAttributeName(int n) {
        switch(n) {
            case 0:
                return "number";
            case 1:
                return "position";
            case 2:
                return "name";
            case 3:
                return "height";
            case 4:
                return "weight";
            case 5:
                return "hometown";
            case 6:
                return "highSchool";
            default:
                return "";
        }
    }

    // Collects all attribute names in a list
    @Override
    public ArrayList<String> getAttributeNames() {
        ArrayList<String> attributeNames = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            attributeNames.add(getAttributeName(i));
        }
        return attributeNames;
    }

//to string
    @Override
    public String toString() {
        return super.toString() + " FootballPlayer{" +
                "number=" + number +
                ", position='" + position + '\'' +
                '}';
    }
}
