package View;
/**
 * Filename: InitialPanel.java
 * Short description: The initial panel that contains CenterPanel
 * IST 242 Assignment: L05
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/21/2024
 */

import javax.swing.*;
import java.awt.*;

public class InitialPanel extends JPanel {
    private CenterPanel cp;
    private WestPanel wp;

    public InitialPanel()
    {
        setLayout(new BorderLayout());
        setBackground(Color.darkGray);

        // add CenterPanel
        cp = new CenterPanel();
        add(cp, "Center");

        wp = new WestPanel();
        add(wp,"West");

    }

    // Setters and Getters
    public WestPanel getWp() {
        return wp;
    }

    public void setWp(WestPanel wp) {
        this.wp = wp;
    }
    public CenterPanel getCp() {
        return cp;
    }

    public void setCp(CenterPanel cp) {
        this.cp = cp;
    }
}

