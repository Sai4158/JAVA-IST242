package View;/*
 * Filename: WestPanel.java
 * Short description: Panel to select sorting type in the GUI
 * IST 242 Assignment: L05
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/21/2024
 */

import javax.swing.*;
import java.awt.*;

public class WestPanel extends JPanel {
    // Buttons
    private JButton merge;
    private JButton quick;
    private JButton selection;

    // panel layout and components
    public WestPanel() {
        setLayout(new GridLayout(4, 1, 6, 6));

        // Create and add a label to the panel
        JLabel label = new JLabel("Choose SORT Type", SwingConstants.CENTER);
        label.setForeground(Color.white);
        label.setBackground(Color.darkGray);


        label.setOpaque(true);
        add(label);

        //add the Selection Sort button
        selection = new JButton("Selection Sort");
        selection.setBackground(Color.lightGray);


        selection.setOpaque(true);
        add(selection);

        //add the Merge Sort button
        merge = new JButton("Merge Sort");
        merge.setForeground(Color.black);


        merge.setBackground(Color.lightGray);
        merge.setOpaque(true);

        add(merge);

        //add the Quick Sort button
        quick = new JButton("Quick Sort");


        quick.setBackground(Color.lightGray);
        quick.setOpaque(true);

        add(quick);
    }

    // get
    public JButton getSelection() {
        return selection;
    }

    // get
    public JButton getMerge() {
        return merge;
    }

    // get
    public JButton getQuick() {
        return quick;
    }
}