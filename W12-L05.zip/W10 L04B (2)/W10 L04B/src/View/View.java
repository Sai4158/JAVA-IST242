package View;
/**
 * Filename: View.java
 * Short description: Represents the GUI for the app
 * IST 242 Assignment: L05
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/21/2024
 */

import java.util.ArrayList;

public class View {
    // Main window frame
    private InitialFrame iFrame;
    private CenterPanel cp;

    // Constructor for the frame
    public View() {
        iFrame = new InitialFrame();
        cp = iFrame.getIp().getCp();
    }

   //gets
    public CenterPanel getCp() {
        return cp;
    }
    public InitialFrame getiFrame() {
        return iFrame;
    }
    // Sets
    public void setiFrame(InitialFrame iFrame) {
        this.iFrame = iFrame;
    }


    // Displays a string
    public void basicDisplay(String s) {
        System.out.println(s);
    }

    //array list of strings
    public void basicDisplay(ArrayList<String> arr) {
        for (String s : arr) {
            System.out.print(s + " ");
        }
        System.out.println("\b");
    }

    // Displays lines of data
    public void linesDisplay(ArrayList<ArrayList<String>> arrOfarr) {
        for (ArrayList<String> line : arrOfarr) {
            basicDisplay(line);
        }
    }
}