package View;
/**
 * Filename: CenterPanel.java
 * Short description: The panel that displays the data
 * IST 242 Assignment: L05
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/21/2024
 */

import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;


public class CenterPanel extends JPanel {
    // header and row data
    private ArrayList<JButton> Header;
    private ArrayList<JButton> RowData;

    // lists and panel properties
    public CenterPanel() {
        super();
        Header = new ArrayList<>();
        RowData = new ArrayList<>();
    }

    // Returns the list
    public ArrayList<JButton> getHeaders() {
        return Header;
    }

    // Sets up the grid layout
    public void CenterInitialSetup(int rows, int cols) {
        setLayout(new GridLayout(rows + 1, cols)); // Includes one row for headers

        for (int c = 0; c < cols; c++) {
            JButton label = new JButton("Label" + c);
            label.setHorizontalAlignment(JLabel.CENTER);
            label.setBackground(Color.WHITE);
            label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            Header.add(label);
            add(label);
        }

        // data buttons for each cell
        for (int r = 0; r < rows; r++) {
            for (int z = 0; z < cols; z++) {
                JButton btn = new JButton("B" + r + z);
                btn.setBackground(Color.orange);
                RowData.add(btn);
                add(btn);
            }
        }

        validate();
        repaint();
    }

    // Updates headers and row data
    public void CenterUpdate(ArrayList<ArrayList<String>> rows, ArrayList<String> head) {
        // Update header text
        for (int h = 0; h < head.size(); h++) {
            Header.get(h).setText(head.get(h));
        }

        // Update buttons
        int b = 0;
        for (ArrayList<String> data : rows) {
            for (String value : data) {
                RowData.get(b).setText(value);
                b++;
            }
        }
        validate();
        repaint();
    }

    // Returns the list
    public ArrayList<JButton> getRowData() {
        return RowData;
    }
}