package Controller;
/**
 * Filename: Controller.java
 * Short description: Handles the interaction between the Model and View.
 * IST 242 Assignment: L05
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/21/2024
 */

import Model.Model;
import View.View;

import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller {

    private Model model;
    private View view;

    public Controller(View v, Model m) {
        this.view = v;
        this.model = m;

        // from model to view
        view.getCp().CenterInitialSetup(
                model.getFpData().getLinesBeingDisplayed(), model.getFpData().getHeaders().size()
        );

        // Update view with data from model
        view.getCp().CenterUpdate(
                model.getLines(), model.getFpData().getHeaders()
        );

        //event listeners for user interaction
        addListeners();
        addScrolling();
        addSorting();
    }

    // Setup sorting interactions
    private void addSorting() {
        setupSelectionSortListener();
        setupMergeSortListener();
        setupQuickSortListener();
    }

    private void setupSelectionSortListener() {
        view.getiFrame().getIp().getWp().getSelection().addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        // Set and perform selection sort
                        model.getFpData().setSortType(1);
                        model.getFpData().sort(1, model.getFpData().getSortField());
                        updateSortUI(view.getiFrame().getIp().getWp(), "Select below!");
                    }
                }
        );
    }

    // Listener for merge sort
    private void setupMergeSortListener() {
        view.getiFrame().getIp().getWp().getMerge().addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        // Set and perform merge sort
                        model.getFpData().setSortType(2);
                        model.getFpData().sort(2, model.getFpData().getSortField());
                        updateSortUI(view.getiFrame().getIp().getWp(), "Merge");
                    }
                }
        );
    }

    // Listener
    private void setupQuickSortListener() {
        view.getiFrame().getIp().getWp().getQuick().addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        // Set
                        model.getFpData().setSortType(3);
                        model.getFpData().sort(3, model.getFpData().getSortField());
                        updateSortUI(view.getiFrame().getIp().getWp(), "Quick");
                    }
                }
        );
    }

    // Updates the UI
    private void updateSortUI(JPanel panel, String sortType) {
        // Change button colors based on active sort type
    }

    // Add listeners
    private void addScrolling() {
        view.getiFrame().getIp().getCp().addMouseWheelListener(
                new MouseWheelListener() {
                    public void mouseWheelMoved(MouseWheelEvent e) {
                        // Scroll handling
                        handleScrolling(e);
                    }
                }
        );
    }

    // scrolling logic
    private void handleScrolling(MouseWheelEvent e) {
        int units = e.getUnitsToScroll();
        int first = model.getFpData().getFirstLineToDisplay() + units;
        if (first < 0) first = 0;
        if (first > model.getFpData().getTable().size() - model.getFpData().getLinesBeingDisplayed()) {
            first -= units;
        }

        model.getFpData().setFirstLineToDisplay(first);
        model.getFpData().setLastLineToDisplay(first + model.getFpData().getLinesBeingDisplayed());

        //new data window
        view.getCp().CenterUpdate(model.getLines(), model.getFpData().getHeaders());
    }

    // Add action listeners
    private void addListeners() {
        ArrayList<JButton> headers = view.getiFrame().getIp().getCp().getHeaders();
        for (JButton header : headers) {
            header.addActionListener(
                    new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            // Reset and update on click
                            updateHeaderStates(headers, (JButton)e.getSource());
                        }
                    }
            );
        }
    }

    // Update headers
    private void updateHeaderStates(ArrayList<JButton> headers, JButton activeButton) {
        for (JButton header : headers) {
            if (header == activeButton) {
                model.getFpData().setSortField(headers.indexOf(header));
                header.setBackground(Color.green);
            } else {
                header.setBackground(Color.WHITE);
            }
        }

        // Sort data and update view
        model.getFpData().sort(model.getFpData().getSortType(), model.getFpData().getSortField());
        view.getCp().CenterUpdate(model.getLines(), model.getFpData().getHeaders());
    }
}
