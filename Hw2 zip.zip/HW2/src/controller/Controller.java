package controller;
/*
 * Filename: Controller.java
 * Short description: Manages the data between Model and View
 * IST 242 Assignment: M02 - W03: L01B: Assignment - MVC
 * @author  Sai Rangineeni
 * @version 2/3/2024
 */


import model.Model;
import view.View;

public class Controller {
    // Instance Variables -- define your private data
    private Model model;
    private View view;


    // Constructors
    public Controller(View v, Model m) {
        // initialize default values
        this.view = v;
        this.model = m;
        displayData();

    }

    private void displayData() {
        // Display data from each Person object
        for (int i = 1; i <= model.getPeople().size(); i++) {
            view.basicDisplay(model.getData(i));
    }

        view.basicDisplay(model.getData(6));
    }

}
