package model;
/*
 * Filename: Model.java
 * Short description: Handles the creation and management persons data
 * IST 242 Assignment: M02 - W03: L01B: Assignment - MVC
 * @author  Sai Rangineeni
 * @version 2/3/2024
 */


import java.util.ArrayList;
import java.util.List;

public class Model {
    // Instance Variables -- define your private data
    private List<Person> people;

    // Constructors
    public Model() {
        people = new ArrayList<>();
        loadData();
    }

    private void loadData() {
        // Initialize Person objects with the given data
        people.add(new Person("Marcus Allen", 200, "Upper Marlboro, Md.", "Dr. Henry A. Wise, Jr."));
        people.add(new Person("Kyle Alston", 180, "Robbinsville, N.J.", "Robbinsville"));
        people.add(new Person("Troy Apke", 220, "Mt. Lebanon, Pa.", "Mount Lebanon"));
        people.add(new Person("Matthew Baney", 225, "State College, Pa.", "State College"));
        people.add(new Person());
    }

    // Getters and Setters
    public List<Person> getPeople() {
        return people;
    }

    public void setPeople(List<Person> people) {
        this.people = people;
    }

    public String getData(int n) {
        if (n >= 1 && n <= people.size()) {
            return people.get(n - 1).toString();
        } else {
            return "invalid input parameter";
        }
    }
}
