package view;
/*
 * Filename: View.java
 * Short description: Handles the display of information to the user.
 * IST 242 Assignment: M02 - W03: L01B: Assignment - MVC
 * @author  Sai Rangineeni
 * @version 2/3/2024
 */


public class View {
    public View() {
    }
    /**
     * @param s the String to be displayed.
     */

    public void basicDisplay(String s) {
        // Display the string
        System.out.println(s);
    }
}