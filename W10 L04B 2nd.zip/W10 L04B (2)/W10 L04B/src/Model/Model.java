package Model;
/**
 * Filename: Model.java
 * Short description: Represents the application's data
 * IST 242 Assignment: L04B
 * @author Sai Rangineeni
 * @version 4/13/2024
 */

public class Model {
    private FootballPlayerData fpData;
    //Constructor
    public Model() {
        // Initialize
        this.fpData = new FootballPlayerData();
        this.fpData.setFirstLineToDisplay(0);
        this.fpData.setLineToHighlight(-1);
        this.fpData.setLastLineToDisplay(fpData.getTable().size());
        this.fpData.setLinesBeingDisplayed(fpData.getTable().size());
    }

    // get and set methods
    public FootballPlayerData getFpData() {
        return fpData;
    }

    public void setFpData(FootballPlayerData fpData) {
        this.fpData = fpData;
    }

}
