package Model;
/**
 * Filename: FootballPlayerData.java
 * Short description: list of football players with there data
 * IST 242 Assignment: L04B
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/13/2024
 */

import java.util.ArrayList;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class FootballPlayerData implements TableData, Displayable {
    private ArrayList<TableMember> players;


    // properties for displaying data
    private int firstLineToDisplay;
    private int lineToHighlight;
    private int lastLineToDisplay;
    private int linesBeingDisplayed;

    public FootballPlayerData() {
        this.players = new ArrayList<>();
        loadFromXML("W10 L04B/src/FootballPlayerTable.xml");

        // Initialize display properties based on loaded data
        this.firstLineToDisplay = 0;
        this.lineToHighlight = -1;
        this.lastLineToDisplay = players.size();
        this.linesBeingDisplayed = players.size();
    }

    // Loads player data from the XML file
    public void loadFromXML(String filePath) {
        try {
            File xmlFile = new File(filePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("object");

            System.out.println("Total players found: " + nList.getLength());

            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;

                    NodeList voidList = eElement.getElementsByTagName("void");
                    String name = "";
                    int feet = 0;
                    int inches = 0;
                    int weight = 0;
                    String hometown = "";
                    String highSchool = "";
                    int number = 0;
                    String position = "";

                    for (int i = 0; i < voidList.getLength(); i++) {
                        Node voidNode = voidList.item(i);
                        if (voidNode.getNodeType() == Node.ELEMENT_NODE) {
                            Element voidElement = (Element) voidNode;
                            String property = voidElement.getAttribute("property");
                            switch (property) {
                                case "name":
                                    name = voidElement.getElementsByTagName("string").item(0).getTextContent();
                                    break;
                                case "feet":
                                    feet = Integer.parseInt(voidElement.getElementsByTagName("int").item(0).getTextContent());
                                    break;
                                case "inches":
                                    inches = Integer.parseInt(voidElement.getElementsByTagName("int").item(0).getTextContent());
                                    break;
                                case "weight":
                                    weight = Integer.parseInt(voidElement.getElementsByTagName("int").item(0).getTextContent());
                                    break;
                                case "hometown":
                                    hometown = voidElement.getElementsByTagName("string").item(0).getTextContent();
                                    break;
                                case "highSchool":
                                    highSchool = voidElement.getElementsByTagName("string").item(0).getTextContent();
                                    break;
                                case "number":
                                    number = Integer.parseInt(voidElement.getElementsByTagName("int").item(0).getTextContent());
                                    break;
                                case "position":
                                    position = voidElement.getElementsByTagName("string").item(0).getTextContent();
                                    break;
                            }
                        }
                    }
                    if (number != 0) {
                        this.players.add(new FootballPlayer(name, new Height(feet, inches), weight, hometown, highSchool, number, position));
                    }
                    System.out.println("Player loaded: " + name); // Debug statement
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Methods from TableData and Displayable interfaces
    @Override
    public void loadTable() {
    }

    // Returns a list
    @Override
    public ArrayList<TableMember> getTable() {
        return new ArrayList<>(players);
    }

    @Override
    public ArrayList<String> getHeaders() {
        // Returns headers for displaying player data
        ArrayList<String> headers = new ArrayList<>();
        headers.add("Number");
        headers.add("Position");
        headers.add("Name");
        headers.add("Height");
        headers.add("Weight");
        headers.add("Hometown");
        headers.add("High School");
        return headers;
    }

    // Get players index
    @Override
    public ArrayList<String> getLine(int line) {
        return players.get(line).getAttributes();

    }

    @Override
    public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine) {
        ArrayList<ArrayList<String>> lines = new ArrayList<>();
        for (int i = firstLine; i <= lastLine && i < players.size(); i++) {
            lines.add(players.get(i).getAttributes());
        }
        return lines;
    }

    // Getters and setters
    @Override
    public int getFirstLineToDisplay() {
        return firstLineToDisplay;
    }


    @Override
    public int getLineToHighlight() {
        return lineToHighlight;
    }
    @Override
    public int getLastLineToDisplay() {
        return lastLineToDisplay;
    }
    @Override
    public int getLinesBeingDisplayed() {
        return linesBeingDisplayed;
    }
    @Override
    public void setFirstLineToDisplay(int firstLine) {
        this.firstLineToDisplay = firstLine;
    }
    @Override
    public void setLineToHighlight(int highlightedLine) {
        this.lineToHighlight = highlightedLine;
    }
    @Override
    public void setLastLineToDisplay(int lastLine) {
        this.lastLineToDisplay = lastLine;
    }
    @Override
    public void setLinesBeingDisplayed(int numberOfLines) {
        this.linesBeingDisplayed = numberOfLines;
    }

}
