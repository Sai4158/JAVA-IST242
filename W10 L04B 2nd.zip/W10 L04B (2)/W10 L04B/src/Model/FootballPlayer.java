package Model;
/**
 * Filename: FootballPlayer.java
 * Short description: Represents a football player
 * IST 242 Assignment: L04B
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/13/2024
 */

import java.util.ArrayList;

public class FootballPlayer extends Person implements TableMember {
    // Declare class variables
    private int number;
    private String position;

    // constructor
    public FootballPlayer() {
        super("", new Height(0, 0), 0, "", "");
        this.number = 0;
        this.position = "";
    }

    public FootballPlayer(String name, Height height, int weight, String hometown, String highSchool, int number, String position) {
        super(name, height, weight, hometown, highSchool);
        this.number = number;
        this.position = position;
    }

    // Getters and Setters
    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @Override
    public String getAttribute(int n) {
        switch (n) {
            case 0: return String.valueOf(number);
            case 1: return position;
            case 2: return getName();
            case 3: return getHeight().toString();
            case 4: return String.valueOf(getWeight());
            case 5: return getHometown();
            case 6: return getHighSchool();
            default: return null;
        }
    }

    @Override
    public ArrayList<String> getAttributes() {
        ArrayList<String> attributes = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            attributes.add(getAttribute(i));
        }
        return attributes;
    }

    @Override
    public ArrayList<String> getAttributeNames() {
        ArrayList<String> attributeNames = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            attributeNames.add(getAttributeName(i));
        }
        return attributeNames;
    }


    @Override
    public String getAttributeName(int n) {
        ArrayList<String> attributeNames = getAttributeNames();
        if (n >= 0 && n < attributeNames.size()) {
            return attributeNames.get(n);
        }
        return null;
    }

    // toString method
    @Override
    public String toString() {
        return "FootballPlayer{" +
                "number=" + number +
                ", position='" + position +
                '}';
    }
}