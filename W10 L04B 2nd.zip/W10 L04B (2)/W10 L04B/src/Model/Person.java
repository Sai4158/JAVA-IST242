package Model;
/**
 * Filename: Person.java
 * Short description: Base class for individuals with attributes like name and height
 * IST 242 Assignment: L04B
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/13/2024
 */

public class Person {
    // Private fields for person attributes
    private String name;
    private Height height;
    private int weight;
    private String hometown;
    private String highSchool;

    // Constructor initializes attributes to default values
    public Person() {
        this.name = "";
        this.height = new Height(); // Assuming Height has a no-arg constructor
        this.weight = 0;
        this.hometown = "";
        this.highSchool = "";
    }

    // Constructor for initializing person attributes
    public Person(String name, Height height, int weight, String hometown, String highSchool) {
        this.name = name;
        this.height = height;
        this.weight = weight;
        this.hometown = hometown;
        this.highSchool = highSchool;
    }

    // Get and Set for each attribute
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Height getHeight() {
        return height;
    }

    public void setHeight(Height height) {
        this.height = height;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getHometown() {
        return hometown;
    }

    public void setHometown(String hometown) {
        this.hometown = hometown;
    }

    public String getHighSchool() {
        return highSchool;
    }

    public void setHighSchool(String highSchool) {
        this.highSchool = highSchool;
    }

    // toString method to provide a string representation of the person
    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", height=" + height +
                ", weight=" + weight +
                ", hometown='" + hometown + '\'' +
                ", highSchool='" + highSchool + '\'' +
                '}';
    }
}
