package Model;
/**
 * Filename: Height.java
 * Short description: Height in feet and inches for a person
 * IST 242 Assignment: L04B
 * @author Sai Rangineeni
 * @version 4/13/2024
 */

public class Height {
    private int feet;
    private int inches;

    //Constructor
    public Height(int feet, int inches) {
        this.feet = feet;
        this.inches = inches;
    }
    public Height() {
        this.feet = 0;
        this.inches = 0;
    }


    // Getters and setters

    public int getFeet() {
        return feet;
    }

    public void setFeet(int feet) {
        this.feet = feet;
    }

    public int getInches() {
        return inches;
    }

    public void setInches(int inches) {
        this.inches = inches;
    }

    @Override
    public String toString() {
        return feet + "'" + inches + "\"";
    }
}
