package View;
/**
 * Filename: CenterPanel.java
 * Short description: The panel that displays the data
 * IST 242 Assignment: L04B
 * @author Sai Rangineeni
 * Worked with: Pranav Ramesh
 * @version 4/13/2024
 */

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class CenterPanel extends JPanel {
    //headers label
    private ArrayList<JLabel> headerLabels;
    private ArrayList<ArrayList<JButton>> dataButtons;

    // Constructor sets up the panel with headers and data
    public CenterPanel(ArrayList<String> headers, ArrayList<ArrayList<String>> dataRows) {
        setLayout(new BorderLayout());

        // header pannel
        JPanel headerPanel = createHeaderPanel(headers);
        add(headerPanel, BorderLayout.NORTH);

        //data rows
        JPanel dataPanel = createDataPanel(headers, dataRows);
        add(new JScrollPane(dataPanel), BorderLayout.CENTER);
    }

    // header panel
    private JPanel createHeaderPanel(ArrayList<String> headers) {
        JPanel headerPanel = new JPanel(new GridLayout(1, headers.size()));
        // Light gray background
        headerPanel.setBackground(new Color(211, 211, 211));
        headerLabels = new ArrayList<>();

        for (String header : headers) {
            JLabel label = new JLabel(header, SwingConstants.CENTER);
            headerPanel.add(label);
            headerLabels.add(label);
        }
        return headerPanel;
    }

    // data panel
    private JPanel createDataPanel(ArrayList<String> headers, ArrayList<ArrayList<String>> dataRows) {
        JPanel dataPanel = new JPanel(new GridLayout(dataRows.size(), headers.size()));
        dataButtons = new ArrayList<>();

        for (ArrayList<String> row : dataRows) {
            ArrayList<JButton> buttonRow = new ArrayList<>();
            for (String cell : row) {
                JButton button = new JButton(cell);
                dataPanel.add(button);
                buttonRow.add(button);
            }
            dataButtons.add(buttonRow);
        }
        return dataPanel;
    }
}
